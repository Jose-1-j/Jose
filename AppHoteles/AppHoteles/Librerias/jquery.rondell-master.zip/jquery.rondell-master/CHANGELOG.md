# Changelog

## 1.1.0
* Breaking - Removed wrapping around rondell items. Selector now has to select the items parent. All children will become rondell items.
* Breaking - CSS classes can't be customized anymore to reduce size via minify
* Breaking - Scrollbar switched to css animation
* New - Added cleanup function to remove everything rondell specific
* New - Rondell options can be updated with a new rondell call. Maybe this leads to a wizard :)
* Change - Some performance improvements
